Use WASD to move, use Shift to use Boost - It's currnetly unlimited and hasn't really been worked on yet but it works.
Q and E to cycle through abilities, F to use ability.
Z to open menu. 

Left click = shoot. 

Kill things, get money, try not to die. 
Buy stuff at shop.
Upgrade stuff at shop.
Use item to do kill more better, stay alive longer, etc.

Currently the window does not resize based on your device, you might have to use Ctrl- or Ctrl+ to resize the window, the text might be a bit small.
Also, press F11 for a "full screen" sort of effect. 

Currently there is only the one level and nothing happens at the end, stuff just stops spawning eventually.

The game will save storage locally to the browser. If you CTRL SHIFT R it will clear the browser and reset everything, also you can use the F12 console and do ResetSave(); and it will reset everything.

There are a few things not quite set up or implemented yet such as the Charge Converter attachment, so don't bother unlocking it. 

The performance can be pretty shitty, optimization has not been taken into consideration yet, will eventually switch from arrays on top of arrays nested inside of arrays to object pooling for enemies, shots, and item drops. But for now it is what it is.























Cheat codes - Enter into console (case sensitive)
ILikeMoney(); 
 -- Adds a bunch of money

 UnlimitedPower();
 -- Increases your ships parameters

 HelpMeTomCruise();
 -- Increases maximum health by 100 and heals for 100.

 PumpUpTheJam();
 -- Unlocks all attachments at level 0.